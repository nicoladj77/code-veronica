<?php
/* --------------------------------- */
/* -- define Photocrati constants -- */
/* --------------------------------- */

// Gallery Constants
define( 'PHOTOCRATI_GALLERY_PLACEHOLDER', '<img class="photocrati-placeholder aligncenter" src="' . photocrati_gallery_file_uri('image/gallery-placeholder.gif') . '" alt=""/>' );

?>