<?php 
$themename = "Photocrati Theme";
$shortname = "phototheme";
$version   = '4.3';
?>
