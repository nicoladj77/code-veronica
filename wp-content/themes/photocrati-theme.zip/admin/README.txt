Photocrati Theme Admin

The files containted in the admin folder are strictly for the Photocrati Theme Options panel in the Wordpress admin. We highly recommend that you do not edit these files. We do not support the modification of these files as they are part of the core theme functionality.