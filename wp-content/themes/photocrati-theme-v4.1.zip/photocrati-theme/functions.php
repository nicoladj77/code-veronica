<?php

// These are essential functions for the operation of this theme. 
// DO NOT REMOVE these included files!

include 'functions/version.php';
include 'functions/defines.php';
include 'functions/create-tables.php';
include 'functions/get-updates.php';
include 'functions/create-admin.php';
include 'functions/create-sidebars.php';
include 'functions/misc-functions.php';
include 'functions/create-thematic.php';
include 'functions/ecommerce.php';
include 'functions/img-manage.php';
include 'functions/feeds.php';

// You can insert custom functions below this line
// -----------------------------------------------


?>