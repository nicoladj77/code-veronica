<?php
/* --------------------------------- */
/* -- define Photocrati constants -- */
/* --------------------------------- */

// Gallery Constants
define( 'PHOTOCRATI_GALLERY_PLACEHOLDER', '<img class="photocrati-placeholder aligncenter" src="' . get_bloginfo('template_directory') . '/admin/images/gallery-placeholder.gif" alt=""/>' );

?>